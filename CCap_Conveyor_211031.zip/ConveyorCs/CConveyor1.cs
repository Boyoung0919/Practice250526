﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConveyorCs
{
    class CConveyor1 : CDevice
    {
        public CConveyor1()
        {
            carrier = new CCarrier();
        }

        public override void Process()
        {
            if (bIsAutoConv == true)
            {
                switch (stepConv)
                {
                    case 0:
                        bIsUReq = false;
                        bIsLReq = false;
                        bIsReady = false;
                        statusCwConv = false;
                        statusCcwConv = false;

                        stepConv = 100;
                        break;

                    case 100:
                        bIsLReq = true;
                        if (bIsTrReq)
                        {
                            statusCwConv = true;
                            bIsReady = true;
                            stepConv = 110;
                        }
                        break;

                    case 110:
                        if (bIsBusy)
                        {
                            stepConv = 120;
                        }
                        break;

                    case 120:
                        if(bIsSensorDetect1)
                        {
                            statusCwConv = false;
                            stepConv = 130;
                        }
                        break;

                    case 130:
                        if (!bIsTrReq && !bIsBusy && bIsCompt)
                        {
                            bIsLReq = false;
                            bIsReady = false;
                            stepConv = 140;
                        }
                        break;

                    case 140:
                        if (!bIsCompt)
                        {
                            stepConv = 200;
                        }
                        break;

                    case 200:
                        if (!bIsSensorDetect1 && !bIsSensorDetect2)
                        {
                            stepConv = 0;
                        }
                        break;

                    default:
                        stepConv = 0;
                        break;
                }
            }
            else
            {
                stepConv = 0;
            }

            if (oldStepConv != stepConv)
            {
                Console.WriteLine("Conveyor 1 Step = {0}", stepConv);
            }
            oldStepConv = stepConv;
            bIsTakeIn = false;
        }
    }
}
