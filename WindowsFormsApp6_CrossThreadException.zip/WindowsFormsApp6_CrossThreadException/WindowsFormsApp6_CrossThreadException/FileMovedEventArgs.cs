﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp6_CrossThreadException
{
    public class FileMovedEventArgs : EventArgs
    {
        public delegate void FileMovedEventHandler(object sender, FileMovedEventArgs e);

        public string FileName
        {
            get;
            private set;
        }
        public FileMovedEventArgs(string fileName)
        {
            FileName = fileName;
        }
    }
}
