﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConveyorCs
{
    class CConveyor2 : CDevice
    {
        public CConveyor2()
        {
            carrier = new CCarrier();
        }

        public override void Process()
        {
            if (bIsAutoConv == true)
            {
                switch (stepConv)
                {
                    case 0:
                        bIsUReq = false;
                        bIsLReq = false;
                        bIsReady = false;
                        statusCwConv = false;
                        statusCcwConv = false;

                        stepConv = 100;
                        break;

                    case 100:
                        if (bIsSensorDetect2 == true)
                        {
                            stepConv = 200;
                        }
                        else
                        {
                            if (bIsTakeIn == true)
                            {
                                stepConv = 110;
                                countConv = 0;
                            }
                        }
                        break;

                    case 110:
                        statusCcwConv = true;
                        if (bIsSensorDetect2 == true)
                        {
                            statusCcwConv = false;
                            bIsUReq = true;
                            stepConv = 200;
                        }
                        break;

                    case 200:
                        if (bIsSensorDetect2 == false)
                        {
                            stepConv = 100;
                        }
                        else if (bIsTrReq)
                        {
                            stepConv = 210;
                            bIsReady = true;
                        }
                        break;

                    case 210:
                        if (bIsBusy)
                        {
                            bIsUReq = true;
                            stepConv = 220;
                        }
                        break;

                    case 220:
                        statusCcwConv = true;
                        if (!bIsTrReq && !bIsBusy && bIsCompt)
                        {
                            bIsUReq = false;
                            bIsReady = false;
                            statusCcwConv = false;
                            stepConv = 230;
                        }
                        break;

                    case 230:
                        if (!bIsCompt)
                            stepConv = 100;
                        break;

                    default:
                        stepConv = 0;
                        break;
                }
            }
            else
            {
                stepConv = 0;
            }

            if (oldStepConv != stepConv)
            {
                Console.WriteLine("Conveyor 2 Step = {0}", stepConv);
            }
            oldStepConv = stepConv;
            bIsTakeIn = false;
        }
    }
}
