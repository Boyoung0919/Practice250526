﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConveyorCs
{
    class CConveyor4 : CDevice
    {
        public CConveyor4()
        {
            carrier = new CCarrier();
        }

        public override void Process()
        {
            if (bIsAutoConv == true)
            {
                switch (stepConv)
                {
                    case 0:
                        bIsUReq = false;
                        bIsLReq = false;
                        bIsReady = false;
                        statusCwConv = false;
                        statusCcwConv = false;

                        stepConv = 100;
                        break;

                    case 100:
                        bIsLReq = true;
                        if (bIsTrReq)
                        {
                            statusCcwConv = true;
                            bIsReady = true;
                            stepConv = 110;
                        }
                        break;

                    case 110:
                        if (bIsBusy)
                        {
                            stepConv = 120;
                        }
                        break;

                    case 120:
                        if (bIsSensorDetect2)
                        {
                            statusCcwConv = false;
                            stepConv = 130;
                        }
                        break;

                    case 130:
                        if (!bIsTrReq && !bIsBusy && bIsCompt)
                        {
                            bIsLReq = false;
                            bIsReady = false;
                            stepConv = 140;
                        }
                        break;

                    case 140:
                        if (!bIsCompt)
                        {
                            stepConv = 200;
                        }
                        break;

                    case 200:
                        if (carrier.use == CCarrier.USE.USE_TAKEOUT)
                        {
                            bIsUReq = true;
                        }
                        if (bIsSensorDetect2 == false)
                        {
                            stepConv = 100;
                        }
                        else if (bIsTrReq)
                        {
                            stepConv = 210;
                            bIsReady = true;
                        }
                        break;

                    case 210:
                        if (bIsBusy)
                        {
                            bIsUReq = true;
                            stepConv = 220;
                        }
                        break;

                    case 220:
                        statusCcwConv = true;
                        if (!bIsTrReq && !bIsBusy && bIsCompt)
                        {
                            bIsUReq = false;
                            bIsReady = false;
                            statusCcwConv = false;
                            stepConv = 230;
                        }
                        break;

                    case 230:
                        if (!bIsCompt)
                            stepConv = 100;
                        break;

                    default:
                        stepConv = 0;
                        break;
                }
            }
            else
            {
                stepConv = 0;
            }

            if (oldStepConv != stepConv)
            {
                Console.WriteLine("Conveyor 4 Step = {0}", stepConv);
            }
            oldStepConv = stepConv;
            bIsTakeIn = false;
        }
    }
}
