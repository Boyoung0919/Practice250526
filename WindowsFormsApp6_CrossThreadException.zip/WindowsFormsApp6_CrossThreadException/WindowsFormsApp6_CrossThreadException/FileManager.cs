﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using static WindowsFormsApp6_CrossThreadException.FileMovedEventArgs;

namespace WindowsFormsApp6_CrossThreadException
{
    public static class FileManager
    {
        public static FileMovedEventHandler FileMovedEventHandler = null;
        
        static List<string> source = new List<string>();
        
        public static List<string> Source
        {
            get
            {
                return source;
            }
        }
        static FileManager()
        {
            DirectoryInfo di = new DirectoryInfo(src_dir);
            FileInfo[] fls = di.GetFiles();
            foreach(FileInfo fi in fls)
            {
                if (fi.Attributes == FileAttributes.Archive)
                {
                    source.Add(fi.Name);    
                }
            }
        }

        static string src_dir = @"src\";
        static string dst_dlr = @"dst\";

        delegate void MoveDele();

        public static void MoveStartAsync()
        {
            MoveDele dele = MoveStart;
            dele.BeginInvoke(null, null);
        }

        public static void MoveStart()
        {
            while(source.Count > 0)
            {
                MoveFile(source[0], src_dir, dst_dlr);
            }
        }

        private static void MoveFile(string s, string src_dir, string dst_dir)
        {
            string src = string.Format("{0}{1}", src_dir, s);
            string dst = string.Format("{0}{1}", dst_dir, s);
            File.Move(src, dst);
            Thread.Sleep(1000);  // 의도적으로 시간이 걸리는 작업처럼 지연
            if(FileMovedEventHandler != null)
            {
                FileMovedEventHandler(null, new FileMovedEventArgs(s));
            }
            source.Remove(s);
        }
    }
}