﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConveyorCs
{
    class RPIOcs
    {
        private bool bIsTrReq;
        private bool bIsBusy;
        private bool bIsCompt;
        private bool bIsUReq;
        private bool bIsLReq;
        private bool bIsReady;

        public bool TrReq
        {
            get { return bIsTrReq; }
            set { bIsTrReq = value; }
        }
        public bool Busy
        {
            get { return bIsBusy; }
            set { bIsBusy = value; }
        }
        public bool Compt
        {
            get { return bIsCompt; }
            set { bIsCompt = value; }
        }
        public bool UReq
        {
            get { return bIsUReq; }
            set { bIsUReq = value; }
        }
        public bool LReq
        {
            get { return bIsLReq; }
            set { bIsLReq = value; }
        }
        public bool Ready
        {
            get { return bIsReady; }
            set { bIsReady = value; }
        }
    }
}
